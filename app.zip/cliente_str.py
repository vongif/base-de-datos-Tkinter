import socket
import sys
import binascii
import observador
import decoradores


HOST, PORT = "localhost", 9999
data = " ".join(sys.argv[1:])
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# ################################################
mensaje = "Hello, World!"

sock.sendto(mensaje.encode("UTF-8"), (HOST, PORT))
received = sock.recvfrom(1024)

# ===== ENVIO Y RECEPCIÓN DE DATOS =================

print("Recibi el alta del registro:  ")
print("seeeeee", observador.ConcreteObserverA.update(str(object)))
print("seeeeee", decoradores.decorador_alta)
print(received)
print("Estoy conectado  " + "--------------------------------")
print(data)
print(sock)


# ===== FIN ENVIO Y RECEPCIÓN DE DATOS =================
